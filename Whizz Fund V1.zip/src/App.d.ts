declare function App(): import("react").JSX.Element;
export default App;
