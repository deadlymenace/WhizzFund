export declare function useIsMobile(): boolean;
