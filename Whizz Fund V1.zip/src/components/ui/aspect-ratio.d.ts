import * as AspectRatioPrimitive from "@radix-ui/react-aspect-ratio";
declare const AspectRatio: import("react").ForwardRefExoticComponent<AspectRatioPrimitive.AspectRatioProps & import("react").RefAttributes<HTMLDivElement>>;
export { AspectRatio };
