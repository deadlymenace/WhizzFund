export declare function Toaster(): import("react").JSX.Element;
