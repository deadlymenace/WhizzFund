import React from 'react';
import { WizardFundDashboard } from '@/components/WizardFundDashboard';

export const HomePage: React.FC = () => {
  return <WizardFundDashboard />;
};

export default HomePage;